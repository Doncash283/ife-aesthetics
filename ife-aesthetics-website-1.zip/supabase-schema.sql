-- If your existing Supabase database already has these tables, do not run this blindly.
-- This schema is for a fresh starter. Review it first.
create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text default '',
  price numeric(12,2) not null default 0,
  category text not null check (category in ('Beauty','Fashion','Accessories','Home Decor')),
  image_url text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;

drop policy if exists "Public can view active products" on public.products;
create policy "Public can view active products"
on public.products for select
to anon, authenticated
using (active = true);

-- Admin writes should be handled by Supabase Auth + a separate admin policy.
-- Do NOT create an open INSERT/UPDATE policy for anon users.
