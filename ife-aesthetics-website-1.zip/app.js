const state={products:[],cart:JSON.parse(localStorage.getItem("ife_cart")||"[]")};
const money=n=>new Intl.NumberFormat("en-NG",{style:"currency",currency:"NGN",maximumFractionDigits:0}).format(Number(n)||0);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

async function loadProducts(){
  const grid=document.querySelector("#productGrid"), empty=document.querySelector("#empty");
  if(!window.SUPABASE_URL || window.SUPABASE_URL.includes("YOUR-PROJECT")){
    empty.hidden=false; grid.innerHTML=""; return;
  }
  try{
    const r=await fetch(`${window.SUPABASE_URL}/rest/v1/products?select=*&active=eq.true&order=created_at.desc`,
      {headers:{apikey:window.SUPABASE_PUBLISHABLE_KEY,Authorization:`Bearer ${window.SUPABASE_PUBLISHABLE_KEY}`}});
    if(!r.ok) throw new Error("Could not load products");
    state.products=await r.json(); renderProducts("All");
  }catch(e){console.error(e);grid.innerHTML="";empty.hidden=false;}
}
function renderProducts(filter="All"){
  const grid=document.querySelector("#productGrid"),empty=document.querySelector("#empty");
  const list=filter==="All"?state.products:state.products.filter(p=>p.category===filter);
  grid.innerHTML=list.map(p=>`<article class="card"><img src="${esc(p.image_url||"https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=700&q=80")}" alt="${esc(p.name)}"><div class="info"><p>${esc(p.category||"Ife Aesthetics")}</p><h3>${esc(p.name)}</h3><p>${esc(p.description||"")}</p><div class="price">${money(p.price)}</div><button class="add" data-id="${esc(p.id)}">Add to bag</button></div></article>`).join("");
  empty.hidden=list.length>0;
}
function add(id){const p=state.products.find(x=>String(x.id)===String(id));if(!p)return;state.cart.push(p);saveCart();renderCart();}
function saveCart(){localStorage.setItem("ife_cart",JSON.stringify(state.cart));document.querySelector("#cartCount").textContent=state.cart.length;}
function renderCart(){
 const box=document.querySelector("#cartItems");
 box.innerHTML=state.cart.length?state.cart.map((p,i)=>`<div class="cart-row"><img src="${esc(p.image_url||"")}"><div><b>${esc(p.name)}</b><br>${money(p.price)}<br><button onclick="removeItem(${i})">Remove</button></div></div>`).join(""):"<p>Your bag is empty.</p>";
 document.querySelector("#cartTotal").textContent=money(state.cart.reduce((s,p)=>s+Number(p.price||0),0));saveCart();
}
function removeItem(i){state.cart.splice(i,1);saveCart();renderCart();}
function whatsapp(){
 if(!state.cart.length)return alert("Your bag is empty.");
 const total=state.cart.reduce((s,p)=>s+Number(p.price||0),0);
 const lines=state.cart.map(p=>`• ${p.name} — ${money(p.price)}`).join("\n");
 const msg=`Hello Ife Aesthetics, I would like to order:\n${lines}\n\nTotal: ${money(total)}\nPlease confirm availability and delivery details.`;
 window.open(`https://wa.me/${window.WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`,"_blank");
}
document.addEventListener("click",e=>{
 if(e.target.matches(".add"))add(e.target.dataset.id);
 if(e.target.matches(".filters button")){document.querySelectorAll(".filters button").forEach(b=>b.classList.remove("active"));e.target.classList.add("active");renderProducts(e.target.dataset.filter);}
 if(e.target.matches(".categories a")){const f=e.target.dataset.filter;setTimeout(()=>{document.querySelectorAll(".filters button").forEach(b=>b.classList.toggle("active",b.dataset.filter===f));renderProducts(f)},0)}
});
document.querySelector("#cartBtn").onclick=()=>document.querySelector("#cartPanel").classList.add("open");
document.querySelector("#closeCart").onclick=()=>document.querySelector("#cartPanel").classList.remove("open");
document.querySelector("#checkoutBtn").onclick=whatsapp;
saveCart();loadProducts();
