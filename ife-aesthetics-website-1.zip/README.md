# Ife Aesthetics

A lightweight storefront for Beauty, Fashion, Accessories and Home Decor.

## Setup

1. Open `config.js`.
2. Replace `SUPABASE_URL` with your Supabase Project URL.
3. Replace `SUPABASE_PUBLISHABLE_KEY` with your Supabase Publishable key.
4. Keep the Supabase secret/service-role key private.
5. If starting with a new database, review and run `supabase-schema.sql`.
6. Upload the files to GitHub.
7. Deploy the repository using a static hosting service such as Cloudflare Pages or Netlify.

## Products

The storefront reads active rows from the `products` table. Product images can be public image URLs.

## WhatsApp

Orders open WhatsApp using the configured store number in `config.js`.

## Security

The browser must never contain a Supabase secret/service-role key. Use RLS and Supabase Auth for admin operations.
