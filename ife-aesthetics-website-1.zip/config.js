// Replace these two values with your Supabase project's public values.
// NEVER put a Supabase secret/service-role key in this file.
window.SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
window.SUPABASE_PUBLISHABLE_KEY = "YOUR_PUBLISHABLE_KEY";
window.WHATSAPP_NUMBER = "2349126492543";
